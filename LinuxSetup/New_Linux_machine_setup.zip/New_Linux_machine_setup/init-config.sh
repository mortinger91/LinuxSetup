#!/bin/bash

echo "First setup completed!"
dirname ${BASH_SOURCE[0]} # save this to CONFIG_DIR
