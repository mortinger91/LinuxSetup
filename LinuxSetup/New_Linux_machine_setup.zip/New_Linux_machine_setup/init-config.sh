#!/bin/bash

echo "First setup completed!"
