#!/bin/bash

echo "Config was updated!!!!!"
